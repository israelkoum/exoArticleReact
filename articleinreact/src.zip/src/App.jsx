import './App.css';
import Blog from './containers/Blog'

function App() {
  return (
    <div className="App">
      <Blog />
    </div>
  );
}

export default App;
